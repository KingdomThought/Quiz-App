package quizApp;

public class QuizApp {

	public static void main(String[] args) {
		
		QuizMaker q1= new QuizMaker();
		q1.questionInput();
		// TODO Auto-generated method stub

	}

}
